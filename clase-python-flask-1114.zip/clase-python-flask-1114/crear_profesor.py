from app import app, db
from app import usuario  # O 'Estudiante' o el modelo que use tu login

with app.app_context():
    # Aquí definimos las credenciales de prueba
    nuevo_profesor = usuario(
        usuario="henry", 
        contrasena="password123", 
        rol="profesor"
    )
    db.session.add(nuevo_profesor)
    db.session.commit()
print("¡Profesor creado con éxito! Usuario: henry | Contraseña: password123")
